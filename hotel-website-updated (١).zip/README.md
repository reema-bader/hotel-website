# Modern Hotel Website

A responsive hotel website built with **HTML, CSS, and JavaScript**.

## Features
- Modern design
- Mobile-friendly navigation
- Smooth scrolling
- Simple form validation

## Technologies
- HTML5
- CSS3 (Flexbox + Media Queries)
- Vanilla JavaScript
