// Mobile Menu
const menuBtn = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

if (menuBtn) {
  menuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
  });
}

// Smooth Scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href'))
      .scrollIntoView({ behavior: 'smooth' });
  });
});

// Form Validation
const form = document.querySelector('form');

if (form) {
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    const name = document.querySelector('#name')?.value;
    const email = document.querySelector('#email')?.value;

    if (!name || !email) {
      alert('Please fill in all fields');
    } else {
      alert('Thank you! Your message has been sent.');
      form.reset();
    }
  });
}
